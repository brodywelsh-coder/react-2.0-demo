import React from "react";

function App() {
  return (
    <div className="App">
      <h1>Welcome to React 2.0 Demo!</h1>
      <p>This is your live React site running instantly in CodeSandbox.</p>
    </div>
  );
}

export default App;