# React 2.0 Demo

This is a minimal React starter project designed to open instantly in CodeSandbox.